package Lab5.Lab5_1;

class ListEmptyException extends RuntimeException
{
    public ListEmptyException(String err)
    {
        super(err);
    }
}
