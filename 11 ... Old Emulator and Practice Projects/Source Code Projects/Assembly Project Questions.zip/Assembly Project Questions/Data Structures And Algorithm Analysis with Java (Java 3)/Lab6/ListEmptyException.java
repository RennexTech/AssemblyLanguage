package Lab6;

class ListEmptyException extends RuntimeException
{
    public ListEmptyException(String err)
    {
        super(err);
    }
}
