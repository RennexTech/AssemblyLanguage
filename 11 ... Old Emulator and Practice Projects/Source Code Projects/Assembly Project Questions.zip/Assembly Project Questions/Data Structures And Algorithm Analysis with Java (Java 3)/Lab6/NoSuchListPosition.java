package Lab6;

class NoSuchListPosition extends RuntimeException
{
    public NoSuchListPosition(String err)
    {
        super(err);
    }
}
