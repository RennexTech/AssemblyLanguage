class Car
{
    private int arithmosAftokinitou;

    Car(int arithmosAftokinitou)
    {
        this.arithmosAftokinitou = arithmosAftokinitou;
    }

    public int getArithmosAftokinitou()
    {
        return arithmosAftokinitou;
    }
}
