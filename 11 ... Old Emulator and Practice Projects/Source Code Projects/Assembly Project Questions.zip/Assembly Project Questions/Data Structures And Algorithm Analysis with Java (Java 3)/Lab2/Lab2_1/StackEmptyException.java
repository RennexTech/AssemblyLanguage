class StackEmptyException extends RuntimeException
{
    public StackEmptyException(String err)
    {
        super(err);
    }
}
