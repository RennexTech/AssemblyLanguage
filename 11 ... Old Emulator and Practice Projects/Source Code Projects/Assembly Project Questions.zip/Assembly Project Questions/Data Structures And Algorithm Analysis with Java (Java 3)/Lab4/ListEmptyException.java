class ListEmptyException extends RuntimeException
{
    public ListEmptyException(String err)
    {
        super(err);
    }
}
