# International Hellenic University Syndos

### Alexander Technological Educational Institute of Thessaloniki  (Until 2019)
