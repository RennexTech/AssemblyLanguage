# Microcomputers-2021
Exercises in 8085, AVR and 8086 assembly, for course Microcomputer Systems, 6th semester 2021 of the Electrical and Computer Engineering School at the National Technical University of Athens. Completed by me and my partner.

8085 exercises were written and simulated in Microlab Studio, AVR in Atmel Studio, and 8086 in 8086 emulator.
